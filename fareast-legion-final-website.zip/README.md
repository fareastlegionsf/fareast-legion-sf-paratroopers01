FAREAST LEGION SF PARATROOPERS final website package.

Includes logo, program/event posters, gallery images, and static AI/FAQ assistant.

Upload index.html and the images folder to your GitHub repository, then commit changes.
